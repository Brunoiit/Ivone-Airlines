npx create-react-app airline-front
cd airline-front
npm install axios react-router-dom
npm install @mui/material @emotion/react @emotion/styled @mui/icons-material
