import React, { useState } from "react";
import axios from "axios";
import { useAuth } from "../context/AuthContext";

export default function CreateFlight() {
  const { token } = useAuth();

  const [flight, setFlight] = useState({
    flight_number: "",
    origin: "",
    destination: "",
    departure_time: "",
    arrival_time: "",
    price: "",
    available_seats: "",
    total_seats: "",
    airline_id: 1,
  });

  const handleChange = (e) => {
    setFlight({ ...flight, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    try {
      await axios.post("http://localhost:8002/flights", flight, {
        headers: { Authorization: `Bearer ${token}` },
      });

      alert("Vuelo creado correctamente");
      setFlight({
        flight_number: "",
        origin: "",
        destination: "",
        departure_time: "",
        arrival_time: "",
        price: "",
        available_seats: "",
        total_seats: "",
        airline_id: 1,
      });
    } catch (error) {
      alert("Error creando vuelo. Revisa los datos.");
      console.log(error.response?.data);
    }
  };

  return (
    <div>
      <h2>Crear Vuelo</h2>
      {Object.keys(flight).map((field) =>
        field !== "airline_id" ? (
          <input
            key={field}
            name={field}
            placeholder={field}
            value={flight[field]}
            onChange={handleChange}
          />
        ) : null
      )}
      <button onClick={handleSubmit}>Crear vuelo</button>
    </div>
  );
}